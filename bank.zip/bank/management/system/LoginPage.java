package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

        public class LoginPage extends JFrame {
            // Components
            private JButton adminLoginButton;
            private JButton customerLoginButton;

            // Constructor
            public LoginPage() {
                // Frame settings
                setTitle("Bank Management System - Main Login");
                setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(2, 1));

        // Initialize components
        adminLoginButton = new JButton("Admin Login");
        customerLoginButton = new JButton("Customer Login");

        // Set button size
        Dimension buttonSize = new Dimension(150, 30);  // Adjust this to your desired size
        adminLoginButton.setPreferredSize(buttonSize);
        customerLoginButton.setPreferredSize(buttonSize);

        // Center buttons using a panel
        JPanel adminPanel = new JPanel();
        JPanel customerPanel = new JPanel();

        adminPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        customerPanel.setLayout(new FlowLayout(FlowLayout.CENTER));

        adminPanel.add(adminLoginButton);
        customerPanel.add(customerLoginButton);

        // Add action listeners for the buttons
        adminLoginButton.addActionListener(this::openAdminLoginPage);
        customerLoginButton.addActionListener(this::openCustomerLoginPage);

        // Add panels to the frame
        add(adminPanel);
        add(customerPanel);

        // Set frame to be visible
        setVisible(true);
    }

    // Method to open Admin Login Page
    private void openAdminLoginPage(ActionEvent e) {
        new AdminLoginPage();  // Opens the admin login page
        dispose();  // Close the main login page after navigating
    }

    // Method to open Customer Login Page
    private void openCustomerLoginPage(ActionEvent e) {
        new CustomerLoginPage();  // Opens the customer login page
        dispose();  // Close the main login page after navigating
    }

    public static void main(String[] args) {
        // Run the Main Login Page
        SwingUtilities.invokeLater(LoginPage::new);
    }
}
