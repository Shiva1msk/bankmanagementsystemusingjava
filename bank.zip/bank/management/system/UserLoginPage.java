package bank.management.system;

public class UserLoginPage {
    public void setVisible(boolean b) {

    }
}
