package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.Vector;

public class ManageAccountsPage {
    private JFrame frame;
    private JTable accountsTable;
    private String[] columnNames = {"Customer ID", "Full Name", "Account Type", "Balance"};
    private Connection connection;

    public ManageAccountsPage() {
        // Set up the frame
        frame = new JFrame("Manage Accounts");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(600, 300);
        frame.setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Manage Accounts", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));

        // Fetch data from the Signup2 table and populate the table
        Object[][] data = fetchAccountData();

        // Create the accounts table with fetched data
        accountsTable = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(accountsTable);

        // Create buttons for account actions
        JPanel buttonPanel = new JPanel();
        JButton editButton = new JButton("Edit");
        JButton deleteButton = new JButton("Delete");
        JButton backButton = new JButton("Back");

        // Add action listeners for buttons
        editButton.addActionListener(e -> editAccount());
        deleteButton.addActionListener(e -> deleteAccount());
        backButton.addActionListener(e -> frame.dispose());

        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(backButton);

        // Add components to the frame
        frame.add(titleLabel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    // Fetch account data from the Signup2 table
    private Object[][] fetchAccountData() {
        Vector<Object[]> data = new Vector<>();

        try (Connection connection = DatabaseConnection.getConnection()) { // Try-with-resources
            String query = "SELECT customer_id, full_name, account_type, initial_balance AS balance FROM signup2";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            // Iterate through the result set and add each row to the data vector
            while (resultSet.next()) {
                String customerId = resultSet.getString("customer_id");
                String fullName = resultSet.getString("full_name");
                String accountType = resultSet.getString("account_type");
                String balance = resultSet.getString("balance");

                // Add row data to the vector
                data.add(new Object[]{customerId, fullName, accountType, balance});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error fetching account data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }

        // Convert the vector to a 2D array and return
        return data.toArray(new Object[0][]);
    }

    // Method for editing an account
    private void editAccount() {
        int selectedRow = accountsTable.getSelectedRow();
        if (selectedRow >= 0) {
            String customerId = (String) accountsTable.getValueAt(selectedRow, 0);
            String currentFullName = (String) accountsTable.getValueAt(selectedRow, 1);
            String currentAccountType = (String) accountsTable.getValueAt(selectedRow, 2);
            String currentBalance = (String) accountsTable.getValueAt(selectedRow, 3);

            // Show a form dialog to edit account details
            JTextField fullNameField = new JTextField(currentFullName);
            JTextField accountTypeField = new JTextField(currentAccountType);
            JTextField balanceField = new JTextField(currentBalance);

            JPanel panel = new JPanel(new GridLayout(0, 2));
            panel.add(new JLabel("Full Name:"));
            panel.add(fullNameField);
            panel.add(new JLabel("Account Type:"));
            panel.add(accountTypeField);
            panel.add(new JLabel("Balance:"));
            panel.add(balanceField);

            int result = JOptionPane.showConfirmDialog(frame, panel, "Edit Account", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                String newFullName = fullNameField.getText();
                String newAccountType = accountTypeField.getText();
                String newBalance = balanceField.getText();

                // Update the database with the new values
                updateAccountInDatabase(customerId, newFullName, newAccountType, newBalance);
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Please select an account to edit.");
        }
    }

    // Method to update account information in the database
    private void updateAccountInDatabase(String customerId, String fullName, String accountType, String balance) {
        String updateQuery = "UPDATE signup2 SET full_name = ?, account_type = ?, initial_balance = ? WHERE customer_id = ?";

        try (Connection connection = DatabaseConnection.getConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setString(1, fullName);
            preparedStatement.setString(2, accountType);
            preparedStatement.setString(3, balance);
            preparedStatement.setString(4, customerId);
            preparedStatement.executeUpdate();

            JOptionPane.showMessageDialog(frame, "Account updated successfully.");
            refreshTableData(); // Refresh the table after updating the account
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error updating account: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method for deleting an account (unchanged)
    private void deleteAccount() {
        int selectedRow = accountsTable.getSelectedRow();
        if (selectedRow >= 0) {
            String customerId = (String) accountsTable.getValueAt(selectedRow, 0);

            // Confirmation dialog for deletion
            int confirm = JOptionPane.showConfirmDialog(frame,
                    "Are you sure you want to delete account " + customerId + "?",
                    "Confirm Deletion", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                try (Connection connection = DatabaseConnection.getConnection()) {
                    String query = "DELETE FROM signup2 WHERE customer_id = ?";
                    PreparedStatement preparedStatement = connection.prepareStatement(query);
                    preparedStatement.setString(1, customerId);
                    preparedStatement.executeUpdate();

                    JOptionPane.showMessageDialog(frame, "Account " + customerId + " deleted.");
                    refreshTableData();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Please select an account to delete.");
        }
    }

    // Method to refresh table data after any update or deletion
    private void refreshTableData() {
        Object[][] data = fetchAccountData();
        accountsTable.setModel(new javax.swing.table.DefaultTableModel(data, columnNames));
    }
}
