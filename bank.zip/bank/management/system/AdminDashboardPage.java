package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.UUID;

public class AdminDashboardPage extends JFrame {
    private JButton registerButton;
    private JButton manageAccountsButton; // Button to manage accounts
    private JButton logoutButton; // New button for logout

    public AdminDashboardPage() {
        // Set frame properties
        setTitle("Admin Dashboard");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the frame on the screen
        setLayout(new FlowLayout()); // Use FlowLayout for better component placement

        // Initialize and configure the register button
        registerButton = new JButton("Register Customer");
        registerButton.addActionListener(this::registerCustomer);

        // Initialize and configure the manage accounts button
        manageAccountsButton = new JButton("Manage Accounts");
        manageAccountsButton.addActionListener(this::manageAccounts);

        // Initialize and configure the logout button
        logoutButton = new JButton("Logout");
        logoutButton.addActionListener(this::logout);

        // Add components to the frame
        add(new JLabel("Welcome to the Admin Dashboard")); // Optional welcome message
        add(registerButton);
        add(manageAccountsButton); // Add manage accounts button
        add(logoutButton); // Add logout button

        // Set frame visibility
        setVisible(true);
    }

    private void registerCustomer(ActionEvent e) {
        // Generate unique customer ID
        String customerId = UUID.randomUUID().toString();
        // Open the Customer Registration Page with the generated customer ID
        new CustomerRegistrationPage(customerId);
    }

    private void manageAccounts(ActionEvent e) {
        // Open the Manage Accounts Page
        new ManageAccountsPage();
    }

    private void logout(ActionEvent e) {
        // Close the current dashboard
        dispose();
        // Open the Admin Login Page again
        new AdminLoginPage();
    }

    public static void main(String[] args) {
        // Launch the Admin Dashboard Page
        SwingUtilities.invokeLater(AdminDashboardPage::new);
    }
}
