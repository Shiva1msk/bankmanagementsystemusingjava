package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CustomerLoginPage extends JFrame {
    // Components for the login page
    private JTextField accountNoField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton cancelButton;

    public CustomerLoginPage() {
        // Frame settings
        setTitle("Customer Login");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close application when the frame is closed
        setLayout(new GridLayout(3, 2));

        // Initialize components
        accountNoField = new JTextField();
        passwordField = new JPasswordField();
        loginButton = new JButton("Login");
        cancelButton = new JButton("Cancel");

        // Add components to the frame
        add(new JLabel("Account Number:"));
        add(accountNoField);
        add(new JLabel("Password:"));
        add(passwordField);
        add(loginButton);
        add(cancelButton);

        // Action listeners for the buttons
        loginButton.addActionListener(this::handleLogin);
        cancelButton.addActionListener(e -> redirectToMainMenu()); // Redirect to main menu

        setVisible(true);
    }

    private void handleLogin(ActionEvent e) {
        String accountNo = accountNoField.getText().trim();
        String password = new String(passwordField.getPassword());

        // Validate input
        if (accountNo.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both account number and password!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Database connection (replace with your actual connection logic)
        Conn conn = new Conn();
        try {
            // Prepare the SQL query to verify credentials
            String sql = "SELECT * FROM login WHERE account_no = ? AND password = ?";
            PreparedStatement pstmt = conn.c.prepareStatement(sql);
            pstmt.setString(1, accountNo);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();

            // Check if any result exists
            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Login successful! Welcome!", "Success", JOptionPane.INFORMATION_MESSAGE);

                // Close the login window
                dispose();

                // Open the Customer Dashboard
                new CustomerDashboard(accountNo); // Pass account number to the dashboard
            } else {
                JOptionPane.showMessageDialog(this, "Invalid account number or password!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            conn.close(); // Close connection in the finally block
        }
    }

    private void redirectToMainMenu() {
        // Close the current frame
        dispose();

        // Here you would typically create a new instance of your main menu or login selection screen
        new LoginPage(); // Assuming there's a MainMenu class for redirecting
    }

    public static void main(String[] args) {
        // Launch the Customer Login Page
        SwingUtilities.invokeLater(CustomerLoginPage::new);
    }
}
