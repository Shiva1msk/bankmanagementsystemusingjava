package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AdminLoginPage extends JFrame {
    private JTextField adminUserField;
    private JPasswordField adminPasswordField;
    private JButton loginButton;
    private JButton cancelButton;

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/bankmanagementsystem"; // Replace with your DB URL
    private static final String DB_USERNAME = "root";  // Replace with your DB username
    private static final String DB_PASSWORD = "shivasu1@#";  // Replace with your DB password

    public AdminLoginPage() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        setTitle("Admin Login");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 2));

        adminUserField = new JTextField();
        adminPasswordField = new JPasswordField();
        loginButton = new JButton("Login");
        cancelButton = new JButton("Cancel");

        add(new JLabel("Username:"));
        add(adminUserField);
        add(new JLabel("Password:"));
        add(adminPasswordField);
        add(loginButton);
        add(cancelButton);

        loginButton.addActionListener(this::handleAdminLogin);
        cancelButton.addActionListener(e -> redirectToMainMenu());

        setVisible(true);
    }

    // Handle admin login by verifying credentials from the admindetails table
    private void handleAdminLogin(ActionEvent e) {
        String username = adminUserField.getText().trim();
        String password = new String(adminPasswordField.getPassword());

        if (validateAdminCredentials(username, password)) {
            JOptionPane.showMessageDialog(this, "Admin Login Successful", "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose(); // Close the login page
            new AdminDashboardPage(); // Open Admin Dashboard
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials! Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to validate admin credentials from the database
    private boolean validateAdminCredentials(String username, String password) {
        boolean isValid = false;

        // Database connection and query
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            String query = "SELECT * FROM admindetails WHERE adminname = ? AND password = ?";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);

            ResultSet resultSet = statement.executeQuery();

            // If the result set contains any rows, the credentials are valid
            isValid = resultSet.next();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return isValid;
    }

    private void redirectToMainMenu() {
        dispose();
        new LoginPage(); // Assuming there's a LoginPage class
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AdminLoginPage::new);
    }
}
